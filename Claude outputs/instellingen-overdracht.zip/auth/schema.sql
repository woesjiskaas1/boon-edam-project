-- ---------------------------------------------------------------------
-- LOGIN EN TOEGANG (portaalgebruikers)
-- Gebaseerd op het ERD: portal_user, system_role, portal_user_role,
-- permission en role_permission. Extra ten opzichte van het ERD:
-- system_role.code en system_role.rank, en de tabel invitation.
-- Dit bestand wordt door auth/routes.php uitgevoerd, los van
-- src/config/database.sql van de rest van de backend.
-- De voorbeeldgegevens worden in PHP aangemaakt (auth/seed.php),
-- omdat wachtwoorden met password_hash() versleuteld moeten worden.
-- ---------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS system_role (
    system_role_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    code VARCHAR(50) UNIQUE NOT NULL,
    name VARCHAR(100) UNIQUE NOT NULL,
    description TEXT NULL,
    `rank` INT NOT NULL
);

CREATE TABLE IF NOT EXISTS permission (
    permission_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    code VARCHAR(50) UNIQUE NOT NULL,
    name VARCHAR(100) UNIQUE NOT NULL,
    description TEXT NULL
);

CREATE TABLE IF NOT EXISTS role_permission (
    system_role_id BIGINT UNSIGNED NOT NULL,
    permission_id BIGINT UNSIGNED NOT NULL,
    PRIMARY KEY (system_role_id, permission_id),
    FOREIGN KEY (system_role_id) REFERENCES system_role(system_role_id) ON DELETE CASCADE,
    FOREIGN KEY (permission_id) REFERENCES permission(permission_id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS portal_user (
    portal_user_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    last_login_at TIMESTAMP NULL
);

CREATE TABLE IF NOT EXISTS portal_user_role (
    portal_user_id BIGINT UNSIGNED NOT NULL,
    system_role_id BIGINT UNSIGNED NOT NULL,
    PRIMARY KEY (portal_user_id, system_role_id),
    FOREIGN KEY (portal_user_id) REFERENCES portal_user(portal_user_id) ON DELETE CASCADE,
    FOREIGN KEY (system_role_id) REFERENCES system_role(system_role_id)
);

CREATE TABLE IF NOT EXISTS invitation (
    invitation_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255) NOT NULL,
    system_role_id BIGINT UNSIGNED NOT NULL,
    expires_at TIMESTAMP NOT NULL,
    accepted_at TIMESTAMP NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (system_role_id) REFERENCES system_role(system_role_id)
)
