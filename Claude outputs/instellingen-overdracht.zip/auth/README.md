# Login-backend (voorstel)

Deze map bevat de login van het HR-portaal. Hij staat bewust **los van de rest van de backend**: er is niets veranderd aan `public/index.php`, `src/config/database.sql` of `src/config/db.php`. Zo ontstaan er geen merge-conflicten met het werk aan de andere endpoints.

| Bestand | Wat |
| --- | --- |
| `public/index.php` | aparte ingang voor `/auth/...`, op poort 3334 |
| `routes.php` | de endpoints |
| `schema.sql` | de tabellen voor de login (worden vanzelf aangemaakt) |
| `seed.php` | voorbeeldgegevens, alleen als de tabellen leeg zijn |

De login gebruikt dezelfde database (`db.php`) en dezelfde pakketten (`vendor/`) als de rest van de backend.

## Starten

Naast de gewone backend (poort 3333), in een eigen terminal:

```bash
cd backend/auth/public
php -S localhost:3334 index.php
```

Lokaal zijn de login-routes ook aan de gewone backend op poort 3333 gekoppeld (twee regels in `public/index.php`), dus één backend starten is genoeg.

## Endpoints

De login gebruikt een PHP-sessie: na het inloggen krijgt de browser een cookie, en de server weet daarmee bij elk verzoek wie er is ingelogd.

| Methode | URL | Doet | Antwoord |
| --- | --- | --- | --- |
| POST | `/auth/login` | inloggen met `email` en `password` | 200 met de gebruiker, 400 of 401 bij een fout |
| POST | `/auth/logout` | uitloggen | 204 |
| GET | `/auth/me` | wie is er ingelogd? | 200 met de gebruiker, 401 als niemand is ingelogd |
| POST | `/auth/register` | account maken met `firstName`, `lastName`, `email`, `password` (alleen met een uitnodiging) | 201 met de gebruiker; 400, 403 of 409 bij een fout |
| GET | `/auth/users` | alle portaalgebruikers, ook gedeactiveerde (alleen ingelogd) | 200, of 401 |
| GET | `/auth/roles` | de vier rollen met hun rechten | 200 |
| GET | `/auth/invitations` | openstaande uitnodigingen (recht `settings`) | 200, 401 of 403 |
| POST | `/auth/invitations` | iemand uitnodigen met `email` en `accessRoleId` | 201; 400, 403 of 409 |
| DELETE | `/auth/invitations/{id}` | uitnodiging intrekken | 204; 403 of 404 |
| PATCH | `/auth/users/{id}/role` | rol wijzigen met `accessRoleId` | 200; 400, 403 of 404 |
| PATCH | `/auth/users/{id}/status` | (de)activeren met `isActive` (true/false) | 200; 400, 403 of 404 |
| DELETE | `/auth/users/{id}` | gebruiker definitief verwijderen | 204; 401, 403 of 404 |

Regels voor beheren (alleen met het recht `settings`, dus Eigenaar en Beheerder):

- Je kunt je eigen rol of toegang niet wijzigen.
- Je kunt alleen gebruikers met een lagere rol dan jij wijzigen.
- Je kunt alleen een rol lager dan die van jou toekennen of uitnodigen.
- Een gedeactiveerde gebruiker kan niet inloggen en is meteen uitgelogd.
- Verwijderen kan niet ongedaan worden gemaakt. Deactiveren wel: kies dat als iemand misschien terugkomt.
- Een uitnodiging verloopt na 30 dagen.

Een gebruiker ziet er in elk antwoord zo uit (nooit met wachtwoord):

```json
{
  "id": 2,
  "firstName": "Jane",
  "lastName": "Doe",
  "name": "Jane Doe",
  "email": "jane.doe@boonedam.com",
  "isActive": true,
  "accessRoleId": "admin",
  "role": { "code": "admin", "name": "Beheerder", "rank": 3 },
  "permissions": ["view", "edit", "settings"]
}
```

Fouten zien er zo uit: `{ "error": "leesbare melding" }`.

## Voorbeeldgegevens

Alleen voor ontwikkelen, aangemaakt door `seed.php` als de tabellen leeg zijn: de accounts `john.doe@`, `jane.doe@`, `jan.devries@` en `sophie.jansen@boonedam.com` met wachtwoord `Welkom123`, en uitnodigingen voor `lisa.bakker@boonedam.com` (Bewerker) en `tom.smit@boonedam.com` (Lezer).

## Afwijkingen van het ERD

- `system_role` heeft extra kolommen `code` en `rank`.
- Er zijn vier rollen in plaats van drie (Eigenaar, Beheerder, Bewerker, Lezer), zoals in de front-end.
- Er is een nieuwe tabel `invitation`.

## Later samenvoegen

Wil het team later één backend, dan zijn twee regels in `public/index.php` genoeg (`require_once` van `auth/routes.php` en `registerAuthRoutes($app);`). Dat is een keuze voor de backend-ontwikkelaar.
