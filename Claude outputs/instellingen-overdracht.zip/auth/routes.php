<?php
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Http\Message\ResponseInterface as Response;
use Slim\App;

require_once __DIR__ . '/seed.php';

const MIN_PASSWORD_LENGTH = 8;

// Verbinding met de database. Maakt de login-tabellen aan als ze nog niet
// bestaan (auth/schema.sql), en vult ze met voorbeeldgegevens als ze leeg zijn.
// We gebruiken de bestaande db-klasse van de backend, zonder die aan te passen.
function authDb(): PDO
{
    $db = (new db())->connect();

    $schema = file_get_contents(__DIR__ . '/schema.sql');
    if ($schema === false) {
        throw new RuntimeException('Could not read auth/schema.sql');
    }
    foreach (array_filter(array_map('trim', explode(';', $schema))) as $statement) {
        $db->exec($statement);
    }

    seedAuth($db);
    return $db;
}

// Start de PHP-sessie. De browser krijgt een cookie (PHPSESSID),
// waarmee de server bij elk volgend verzoek weet wie er is ingelogd.
function startSession(): void
{
    if (session_status() !== PHP_SESSION_ACTIVE) {
        session_set_cookie_params([
            'path' => '/',
            'httponly' => true,   // JavaScript kan het cookie niet lezen
            'samesite' => 'Lax',  // andere websites kunnen het niet meesturen
        ]);
        session_start();
    }
}

// Stuurt JSON terug met een statuscode.
function jsonResponse(Response $response, $data, int $status = 200): Response
{
    $response->getBody()->write(json_encode($data));
    return $response->withStatus($status);
}

// Leest de JSON uit de body. Geeft een lege array als het geen geldige JSON is.
function readJson(Request $request): array
{
    $data = json_decode((string) $request->getBody(), true);
    return is_array($data) ? $data : [];
}

// Haalt een gebruiker op zoals de front-end hem nodig heeft: zonder wachtwoord,
// met zijn toegangsrol en rechten. Geeft null als hij niet bestaat, of als hij
// uit staat (tenzij $includeInactive true is, voor het beheer in Instellingen).
function loadPublicUser(PDO $db, int $userId, bool $includeInactive = false): ?array
{
    $query = $db->prepare(
        'SELECT u.portal_user_id, u.first_name, u.last_name, u.email, u.is_active,
                r.system_role_id, r.code, r.name AS role_name, r.`rank`
         FROM portal_user u
         JOIN portal_user_role ur ON ur.portal_user_id = u.portal_user_id
         JOIN system_role r ON r.system_role_id = ur.system_role_id
         WHERE u.portal_user_id = ?
         ORDER BY r.`rank` DESC
         LIMIT 1'
    );
    $query->execute([$userId]);
    $user = $query->fetch(PDO::FETCH_ASSOC);

    if (!$user || (!$user['is_active'] && !$includeInactive)) {
        return null;
    }

    $rights = $db->prepare(
        'SELECT p.code FROM role_permission rp
         JOIN permission p ON p.permission_id = rp.permission_id
         WHERE rp.system_role_id = ?'
    );
    $rights->execute([$user['system_role_id']]);

    return [
        'id' => (int) $user['portal_user_id'],
        'firstName' => $user['first_name'],
        'lastName' => $user['last_name'],
        'name' => trim($user['first_name'] . ' ' . $user['last_name']),
        'email' => $user['email'],
        'isActive' => (bool) $user['is_active'],
        'accessRoleId' => $user['code'],
        'role' => ['code' => $user['code'], 'name' => $user['role_name'], 'rank' => (int) $user['rank']],
        'permissions' => $rights->fetchAll(PDO::FETCH_COLUMN),
    ];
}

// Het id van de ingelogde gebruiker, of null als niemand is ingelogd.
function currentUserId(): ?int
{
    startSession();
    return isset($_SESSION['portal_user_id']) ? (int) $_SESSION['portal_user_id'] : null;
}

// Controleert of de ingelogde gebruiker gebruikers mag beheren (recht "settings").
// Geeft de ingelogde gebruiker terug, of een foutantwoord (401 of 403).
function authorizeManager(PDO $db, Response $response)
{
    $userId = currentUserId();
    $me = $userId === null ? null : loadPublicUser($db, $userId);

    if ($me === null) {
        return jsonResponse($response, ['error' => 'Niet ingelogd.'], 401);
    }

    if (!in_array('settings', $me['permissions'], true)) {
        return jsonResponse($response, ['error' => 'Je hebt geen rechten om toegang te beheren.'], 403);
    }

    return $me;
}

// Zoekt een rol op aan de hand van de code, bijvoorbeeld "editor".
function findRoleByCode(PDO $db, string $code): ?array
{
    $query = $db->prepare('SELECT system_role_id, code, name, `rank` FROM system_role WHERE code = ?');
    $query->execute([$code]);
    $role = $query->fetch(PDO::FETCH_ASSOC);
    return $role ?: null;
}

// Mag de ingelogde gebruiker ($me) deze andere gebruiker ($target) wijzigen?
// Geeft de reden terug waarom het niet mag, of null als het mag.
// Dezelfde regels als getChangeBlockReason in de front-end.
function changeBlockReason(array $me, array $target): ?string
{
    if ($me['id'] === $target['id']) {
        return 'Je kunt je eigen rol of toegang niet wijzigen.';
    }

    if ($target['role']['rank'] >= $me['role']['rank']) {
        return 'Je kunt alleen gebruikers met een lagere rol dan jij wijzigen.';
    }

    return null;
}

// Een uitnodiging zoals de front-end hem nodig heeft.
function publicInvitation(array $row): array
{
    return [
        'id' => (int) $row['invitation_id'],
        'email' => $row['email'],
        'accessRoleId' => $row['code'],
        'role' => ['code' => $row['code'], 'name' => $row['role_name'], 'rank' => (int) $row['rank']],
        'createdAt' => $row['created_at'],
        'expiresAt' => $row['expires_at'],
    ];
}

function registerAuthRoutes(App $app): void
{
    // ENDPOINT INLOGGEN
    // ---------------------------------------------------------------------
    $app->post('/auth/login', function (Request $request, Response $response) {
        $data = readJson($request);
        $email = strtolower(trim($data['email'] ?? ''));
        $password = (string) ($data['password'] ?? '');

        if ($email === '' || $password === '') {
            return jsonResponse($response, ['error' => 'Vul je e-mailadres en wachtwoord in.'], 400);
        }

        $db = authDb();
        $query = $db->prepare('SELECT portal_user_id, password_hash, is_active FROM portal_user WHERE email = ?');
        $query->execute([$email]);
        $row = $query->fetch(PDO::FETCH_ASSOC);

        // Bewust één melding: we verklappen niet of het e-mailadres bestaat.
        if (!$row || !$row['is_active'] || !password_verify($password, $row['password_hash'])) {
            return jsonResponse($response, ['error' => 'E-mailadres of wachtwoord klopt niet.'], 401);
        }

        startSession();
        session_regenerate_id(true); // nieuw sessie-id na inloggen (tegen session fixation)
        $_SESSION['portal_user_id'] = (int) $row['portal_user_id'];

        $db->prepare('UPDATE portal_user SET last_login_at = NOW() WHERE portal_user_id = ?')
            ->execute([$row['portal_user_id']]);

        return jsonResponse($response, loadPublicUser($db, (int) $row['portal_user_id']));
    });

    // ENDPOINT UITLOGGEN
    // ---------------------------------------------------------------------
    $app->post('/auth/logout', function (Request $request, Response $response) {
        startSession();
        $_SESSION = [];
        session_destroy();
        return $response->withStatus(204);
    });

    // ENDPOINT WIE IS ER INGELOGD?
    // ---------------------------------------------------------------------
    $app->get('/auth/me', function (Request $request, Response $response) {
        $userId = currentUserId();

        if ($userId === null) {
            return jsonResponse($response, ['error' => 'Niet ingelogd.'], 401);
        }

        $user = loadPublicUser(authDb(), $userId);

        if ($user === null) {
            $_SESSION = [];
            return jsonResponse($response, ['error' => 'Niet ingelogd.'], 401);
        }

        return jsonResponse($response, $user);
    });

    // ENDPOINT REGISTREREN (alleen met een uitnodiging)
    // ---------------------------------------------------------------------
    $app->post('/auth/register', function (Request $request, Response $response) {
        $data = readJson($request);
        $firstName = trim($data['firstName'] ?? '');
        $lastName = trim($data['lastName'] ?? '');
        $email = strtolower(trim($data['email'] ?? ''));
        $password = (string) ($data['password'] ?? '');

        if ($firstName === '' || $lastName === '') {
            return jsonResponse($response, ['error' => 'Vul je voornaam en achternaam in.'], 400);
        }
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return jsonResponse($response, ['error' => 'Vul een geldig e-mailadres in.'], 400);
        }
        if (strlen($password) < MIN_PASSWORD_LENGTH) {
            return jsonResponse($response, ['error' => 'Je wachtwoord moet minstens ' . MIN_PASSWORD_LENGTH . ' tekens hebben.'], 400);
        }

        $db = authDb();

        $exists = $db->prepare('SELECT COUNT(*) FROM portal_user WHERE email = ?');
        $exists->execute([$email]);
        if ((int) $exists->fetchColumn() > 0) {
            return jsonResponse($response, ['error' => 'Er is al een account met dit e-mailadres. Log in.'], 409);
        }

        $invitationQuery = $db->prepare(
            'SELECT invitation_id, system_role_id FROM invitation
             WHERE LOWER(email) = ? AND accepted_at IS NULL AND expires_at > NOW()
             ORDER BY created_at DESC LIMIT 1'
        );
        $invitationQuery->execute([$email]);
        $invitation = $invitationQuery->fetch(PDO::FETCH_ASSOC);

        if (!$invitation) {
            return jsonResponse($response, ['error' => 'Dit e-mailadres is niet uitgenodigd. Vraag een beheerder om een uitnodiging.'], 403);
        }

        // Alles of niets: account, rol en uitnodiging in één transactie.
        $db->beginTransaction();
        try {
            $db->prepare('INSERT INTO portal_user (first_name, last_name, email, password_hash) VALUES (?, ?, ?, ?)')
                ->execute([$firstName, $lastName, $email, password_hash($password, PASSWORD_DEFAULT)]);
            $userId = (int) $db->lastInsertId();

            $db->prepare('INSERT INTO portal_user_role (portal_user_id, system_role_id) VALUES (?, ?)')
                ->execute([$userId, $invitation['system_role_id']]);

            $db->prepare('UPDATE invitation SET accepted_at = NOW() WHERE invitation_id = ?')
                ->execute([$invitation['invitation_id']]);

            $db->commit();
        } catch (\Throwable $e) {
            $db->rollBack();
            throw $e;
        }

        // Na registreren meteen ingelogd.
        startSession();
        session_regenerate_id(true);
        $_SESSION['portal_user_id'] = $userId;

        return jsonResponse($response, loadPublicUser($db, $userId), 201);
    });

    // ENDPOINT ALLE PORTAALGEBRUIKERS (voor Instellingen)
    // Ook gebruikers die uit staan, zodat je ze weer toegang kunt geven.
    // ---------------------------------------------------------------------
    $app->get('/auth/users', function (Request $request, Response $response) {
        if (currentUserId() === null) {
            return jsonResponse($response, ['error' => 'Niet ingelogd.'], 401);
        }

        $db = authDb();
        $ids = $db->query('SELECT portal_user_id FROM portal_user ORDER BY portal_user_id')
            ->fetchAll(PDO::FETCH_COLUMN);

        $users = [];
        foreach ($ids as $id) {
            $user = loadPublicUser($db, (int) $id, true);
            if ($user !== null) {
                $users[] = $user;
            }
        }

        return jsonResponse($response, $users);
    });

    // ENDPOINT ALLE TOEGANGSROLLEN (voor keuzelijsten)
    // ---------------------------------------------------------------------
    $app->get('/auth/roles', function (Request $request, Response $response) {
        if (currentUserId() === null) {
            return jsonResponse($response, ['error' => 'Niet ingelogd.'], 401);
        }

        $db = authDb();
        $roles = $db->query('SELECT system_role_id, code, name, description, `rank` FROM system_role ORDER BY `rank` DESC')
            ->fetchAll(PDO::FETCH_ASSOC);

        $rights = $db->prepare(
            'SELECT p.code FROM role_permission rp
             JOIN permission p ON p.permission_id = rp.permission_id
             WHERE rp.system_role_id = ?'
        );

        $result = [];
        foreach ($roles as $role) {
            $rights->execute([$role['system_role_id']]);
            $result[] = [
                'code' => $role['code'],
                'name' => $role['name'],
                'description' => $role['description'],
                'rank' => (int) $role['rank'],
                'permissions' => $rights->fetchAll(PDO::FETCH_COLUMN),
            ];
        }

        return jsonResponse($response, $result);
    });

    // ENDPOINT OPENSTAANDE UITNODIGINGEN
    // ---------------------------------------------------------------------
    $app->get('/auth/invitations', function (Request $request, Response $response) {
        $db = authDb();
        $me = authorizeManager($db, $response);
        if ($me instanceof Response) {
            return $me;
        }

        $rows = $db->query(
            'SELECT i.invitation_id, i.email, i.created_at, i.expires_at, r.code, r.name AS role_name, r.`rank`
             FROM invitation i
             JOIN system_role r ON r.system_role_id = i.system_role_id
             WHERE i.accepted_at IS NULL AND i.expires_at > NOW()
             ORDER BY i.created_at DESC'
        )->fetchAll(PDO::FETCH_ASSOC);

        return jsonResponse($response, array_map('publicInvitation', $rows));
    });

    // ENDPOINT IEMAND UITNODIGEN
    // ---------------------------------------------------------------------
    $app->post('/auth/invitations', function (Request $request, Response $response) {
        $db = authDb();
        $me = authorizeManager($db, $response);
        if ($me instanceof Response) {
            return $me;
        }

        $data = readJson($request);
        $email = strtolower(trim($data['email'] ?? ''));
        $roleCode = trim($data['accessRoleId'] ?? '');

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return jsonResponse($response, ['error' => 'Vul een geldig e-mailadres in.'], 400);
        }

        $role = findRoleByCode($db, $roleCode);
        if ($role === null) {
            return jsonResponse($response, ['error' => 'Kies een geldige toegangsrol.'], 400);
        }

        // Je kunt niemand een rol geven die even hoog of hoger is dan die van jou.
        if ((int) $role['rank'] >= $me['role']['rank']) {
            return jsonResponse($response, ['error' => 'Je kunt alleen een rol lager dan die van jou toekennen.'], 403);
        }

        $exists = $db->prepare('SELECT COUNT(*) FROM portal_user WHERE email = ?');
        $exists->execute([$email]);
        if ((int) $exists->fetchColumn() > 0) {
            return jsonResponse($response, ['error' => 'Er is al een account met dit e-mailadres.'], 409);
        }

        $open = $db->prepare('SELECT COUNT(*) FROM invitation WHERE LOWER(email) = ? AND accepted_at IS NULL AND expires_at > NOW()');
        $open->execute([$email]);
        if ((int) $open->fetchColumn() > 0) {
            return jsonResponse($response, ['error' => 'Dit e-mailadres is al uitgenodigd.'], 409);
        }

        $db->prepare('INSERT INTO invitation (email, system_role_id, expires_at) VALUES (?, ?, DATE_ADD(NOW(), INTERVAL 30 DAY))')
            ->execute([$email, $role['system_role_id']]);

        $query = $db->prepare(
            'SELECT i.invitation_id, i.email, i.created_at, i.expires_at, r.code, r.name AS role_name, r.`rank`
             FROM invitation i JOIN system_role r ON r.system_role_id = i.system_role_id
             WHERE i.invitation_id = ?'
        );
        $query->execute([$db->lastInsertId()]);

        return jsonResponse($response, publicInvitation($query->fetch(PDO::FETCH_ASSOC)), 201);
    });

    // ENDPOINT UITNODIGING INTREKKEN
    // ---------------------------------------------------------------------
    $app->delete('/auth/invitations/{id:\d+}', function (Request $request, Response $response, array $args) {
        $db = authDb();
        $me = authorizeManager($db, $response);
        if ($me instanceof Response) {
            return $me;
        }

        $query = $db->prepare(
            'SELECT r.`rank` FROM invitation i JOIN system_role r ON r.system_role_id = i.system_role_id
             WHERE i.invitation_id = ? AND i.accepted_at IS NULL'
        );
        $query->execute([$args['id']]);
        $rank = $query->fetchColumn();

        if ($rank === false) {
            return jsonResponse($response, ['error' => 'Uitnodiging niet gevonden.'], 404);
        }

        if ((int) $rank >= $me['role']['rank']) {
            return jsonResponse($response, ['error' => 'Je kunt deze uitnodiging niet intrekken.'], 403);
        }

        $db->prepare('DELETE FROM invitation WHERE invitation_id = ?')->execute([$args['id']]);

        return $response->withStatus(204);
    });

    // ENDPOINT ROL VAN EEN GEBRUIKER WIJZIGEN
    // ---------------------------------------------------------------------
    $app->patch('/auth/users/{id:\d+}/role', function (Request $request, Response $response, array $args) {
        $db = authDb();
        $me = authorizeManager($db, $response);
        if ($me instanceof Response) {
            return $me;
        }

        $target = loadPublicUser($db, (int) $args['id'], true);
        if ($target === null) {
            return jsonResponse($response, ['error' => 'Gebruiker niet gevonden.'], 404);
        }

        $reason = changeBlockReason($me, $target);
        if ($reason !== null) {
            return jsonResponse($response, ['error' => $reason], 403);
        }

        $data = readJson($request);
        $role = findRoleByCode($db, trim($data['accessRoleId'] ?? ''));
        if ($role === null) {
            return jsonResponse($response, ['error' => 'Kies een geldige toegangsrol.'], 400);
        }

        if ((int) $role['rank'] >= $me['role']['rank']) {
            return jsonResponse($response, ['error' => 'Je kunt alleen een rol lager dan die van jou toekennen.'], 403);
        }

        // Oude rol weg, nieuwe rol erin: in één transactie.
        $db->beginTransaction();
        try {
            $db->prepare('DELETE FROM portal_user_role WHERE portal_user_id = ?')->execute([$target['id']]);
            $db->prepare('INSERT INTO portal_user_role (portal_user_id, system_role_id) VALUES (?, ?)')
                ->execute([$target['id'], $role['system_role_id']]);
            $db->commit();
        } catch (\Throwable $e) {
            $db->rollBack();
            throw $e;
        }

        return jsonResponse($response, loadPublicUser($db, $target['id'], true));
    });

    // ENDPOINT TOEGANG AFNEMEN OF TERUGGEVEN
    // ---------------------------------------------------------------------
    $app->patch('/auth/users/{id:\d+}/status', function (Request $request, Response $response, array $args) {
        $db = authDb();
        $me = authorizeManager($db, $response);
        if ($me instanceof Response) {
            return $me;
        }

        $target = loadPublicUser($db, (int) $args['id'], true);
        if ($target === null) {
            return jsonResponse($response, ['error' => 'Gebruiker niet gevonden.'], 404);
        }

        $reason = changeBlockReason($me, $target);
        if ($reason !== null) {
            return jsonResponse($response, ['error' => $reason], 403);
        }

        $data = readJson($request);
        if (!array_key_exists('isActive', $data) || !is_bool($data['isActive'])) {
            return jsonResponse($response, ['error' => 'Geef isActive mee als true of false.'], 400);
        }

        $db->prepare('UPDATE portal_user SET is_active = ? WHERE portal_user_id = ?')
            ->execute([$data['isActive'] ? 1 : 0, $target['id']]);

        return jsonResponse($response, loadPublicUser($db, $target['id'], true));
    });

    // Gebruiker definitief verwijderen. Zelfde regels als rol wijzigen:
    // niet jezelf, en alleen iemand met een lagere rol dan jij.
    // Zijn rol in portal_user_role verdwijnt vanzelf (ON DELETE CASCADE).
    // Tip: deactiveren (PATCH .../status) kan later teruggedraaid worden,
    // verwijderen niet.
    $app->delete('/auth/users/{id:\d+}', function (Request $request, Response $response, array $args) {
        $db = authDb();
        $me = authorizeManager($db, $response);
        if ($me instanceof Response) {
            return $me;
        }

        $target = loadPublicUser($db, (int) $args['id'], true);
        if ($target === null) {
            return jsonResponse($response, ['error' => 'Gebruiker niet gevonden.'], 404);
        }

        $reason = changeBlockReason($me, $target);
        if ($reason !== null) {
            return jsonResponse($response, ['error' => $reason], 403);
        }

        $db->prepare('DELETE FROM portal_user WHERE portal_user_id = ?')
            ->execute([$target['id']]);

        return $response->withStatus(204);
    });
}
