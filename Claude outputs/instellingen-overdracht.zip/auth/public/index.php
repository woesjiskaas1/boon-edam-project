<?php
// Aparte ingang voor de login-endpoints (/auth/...).
// Staat los van public/index.php, zodat de bestanden van de rest van de
// backend niet aangepast hoeven te worden (geen merge-conflicten).
//
// Starten (in de map backend/auth/public):
//   php -S localhost:3334 index.php

use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Server\RequestHandlerInterface as RequestHandler;
use Slim\Factory\AppFactory;

// Dezelfde pakketten en dezelfde databaseverbinding als de rest van de backend.
require_once __DIR__ . '/../../vendor/autoload.php';
require_once __DIR__ . '/../../src/config/db.php';
require_once __DIR__ . '/../routes.php';

$app = AppFactory::create();

registerAuthRoutes($app);

// Onbekende URL: 404 als JSON.
$app->any('/{routes:.+}', function (Request $request, Response $response) {
    $response->getBody()->write(json_encode(['error' => 'Niet gevonden.']));
    return $response->withStatus(404);
});

// Elk antwoord is JSON.
$app->add(function (Request $request, RequestHandler $handler) {
    $response = $handler->handle($request);
    return $response->withHeader('Content-Type', 'application/json');
});

// Bij een onverwachte fout: alleen een algemene melding naar de browser,
// geen details over bestanden of de database. De details komen in de terminal.
$errorMiddleware = $app->addErrorMiddleware(false, true, true);
$errorMiddleware->setDefaultErrorHandler(function (Request $request, \Throwable $exception) use ($app) {
    error_log((string) $exception);
    $response = $app->getResponseFactory()->createResponse(500);
    $response->getBody()->write(json_encode(['error' => 'Er ging iets mis op de server.']));
    return $response->withHeader('Content-Type', 'application/json');
});

$app->run();
