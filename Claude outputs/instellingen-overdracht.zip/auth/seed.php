<?php
/**
 * Voorbeeldgegevens voor de login, alleen voor ontwikkelen en testen.
 * Wordt alleen uitgevoerd als de tabellen nog leeg zijn.
 */
function seedAuth(PDO $db): void
{
    $roleCount = (int) $db->query('SELECT COUNT(*) FROM system_role')->fetchColumn();

    if ($roleCount === 0) {
        $roles = [
            ['owner', 'Eigenaar', 'Eigenaar van het portaal. Kan alles en kan niet verwijderd worden.', 4],
            ['admin', 'Beheerder', 'Kan alles, ook de instellingen en wie toegang heeft.', 3],
            ['editor', 'Bewerker', 'Kan medewerkers, functies en skills toevoegen en aanpassen.', 2],
            ['viewer', 'Lezer', 'Kan alles bekijken, maar niets aanpassen.', 1],
        ];
        $insertRole = $db->prepare('INSERT INTO system_role (code, name, description, `rank`) VALUES (?, ?, ?, ?)');
        foreach ($roles as $role) {
            $insertRole->execute($role);
        }

        $permissions = [
            ['view', 'Medewerkers en rollen bekijken'],
            ['edit', 'Medewerkers en rollen toevoegen en aanpassen'],
            ['settings', 'Instellingen en toegang beheren'],
        ];
        $insertPermission = $db->prepare('INSERT INTO permission (code, name) VALUES (?, ?)');
        foreach ($permissions as $permission) {
            $insertPermission->execute($permission);
        }

        // Welke rol welke rechten heeft.
        $rights = [
            'owner' => ['view', 'edit', 'settings'],
            'admin' => ['view', 'edit', 'settings'],
            'editor' => ['view', 'edit'],
            'viewer' => ['view'],
        ];
        $link = $db->prepare(
            'INSERT INTO role_permission (system_role_id, permission_id)
             SELECT r.system_role_id, p.permission_id FROM system_role r, permission p
             WHERE r.code = ? AND p.code = ?'
        );
        foreach ($rights as $roleCode => $permissionCodes) {
            foreach ($permissionCodes as $permissionCode) {
                $link->execute([$roleCode, $permissionCode]);
            }
        }
    }

    $userCount = (int) $db->query('SELECT COUNT(*) FROM portal_user')->fetchColumn();

    if ($userCount === 0) {
        // Demo-accounts. Het wachtwoord wordt nooit als tekst opgeslagen, alleen als hash.
        $users = [
            ['John', 'Doe', 'john.doe@boonedam.com', 'owner'],
            ['Jane', 'Doe', 'jane.doe@boonedam.com', 'admin'],
            ['Jan', 'de Vries', 'jan.devries@boonedam.com', 'editor'],
            ['Sophie', 'Jansen', 'sophie.jansen@boonedam.com', 'viewer'],
        ];
        $insertUser = $db->prepare(
            'INSERT INTO portal_user (first_name, last_name, email, password_hash) VALUES (?, ?, ?, ?)'
        );
        $insertUserRole = $db->prepare(
            'INSERT INTO portal_user_role (portal_user_id, system_role_id)
             SELECT ?, system_role_id FROM system_role WHERE code = ?'
        );
        foreach ($users as [$firstName, $lastName, $email, $roleCode]) {
            $insertUser->execute([$firstName, $lastName, $email, password_hash('Welkom123', PASSWORD_DEFAULT)]);
            $insertUserRole->execute([$db->lastInsertId(), $roleCode]);
        }
    }

    $invitationCount = (int) $db->query('SELECT COUNT(*) FROM invitation')->fetchColumn();

    if ($invitationCount === 0) {
        $insertInvitation = $db->prepare(
            'INSERT INTO invitation (email, system_role_id, expires_at)
             SELECT ?, system_role_id, DATE_ADD(NOW(), INTERVAL 30 DAY) FROM system_role WHERE code = ?'
        );
        $insertInvitation->execute(['lisa.bakker@boonedam.com', 'editor']);
        $insertInvitation->execute(['tom.smit@boonedam.com', 'viewer']);
    }
}
