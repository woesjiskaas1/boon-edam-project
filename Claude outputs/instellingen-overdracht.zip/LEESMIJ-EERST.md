# Overdracht: Instellingen-pagina (portaalgebruikers beheren)

Deze zip bevat een **tijdelijke, lokale login-backend**, zodat je de Instellingen-pagina kunt bouwen en testen. De echte backend maakt Alex. Deze code is alleen een voorbeeld van hoe het werkt.

**Belangrijk: niets van `backend/auth` gaat naar GitHub of in een commit.**

## Inhoud

| Map / bestand | Wat |
| --- | --- |
| `auth/` | de login-backend: `routes.php`, `schema.sql`, `seed.php`, `README.md` |
| `voor-frontend/userManagementService.js` | alle `fetch`-functies voor de Instellingen-pagina |

## 1. Backend installeren (eenmalig)

1. Pak de map `auth` uit in `backend/`, zodat je `backend/auth/routes.php` hebt.
2. Zorg dat Git de map negeert. Voeg deze regel toe aan `.git/info/exclude` (niet aan `.gitignore`, want die wordt wél gecommit):
   ```
   backend/auth/
   ```
3. Open `backend/public/index.php` en voeg twee regels toe:
   - bovenaan, bij de andere `require_once`-regels:
     ```php
     require_once __DIR__ . '/../auth/routes.php';
     ```
   - direct na `$app = AppFactory::create();`:
     ```php
     registerAuthRoutes($app);
     ```
4. Dit bestand is van Alex. Zorg dat jouw wijziging niet in een commit komt:
   ```bash
   git update-index --skip-worktree backend/public/index.php
   ```
   (Terugdraaien kan met `--no-skip-worktree`.)

## 2. Starten

1. Start de database (DBngin).
2. Start de backend:
   ```bash
   cd backend/public
   php -S localhost:3333 index.php
   ```
3. Start de front-end met `npm run dev`.

De tabellen en de voorbeeldgegevens worden bij het eerste verzoek vanzelf aangemaakt.

Geeft de backend een fout als "Connection refused"? Dan draait de database niet, of staat in `backend/src/config/db.php` de host op `localhost` in plaats van `127.0.0.1`.

## 3. Testaccounts

Het wachtwoord is voor alle accounts `Welkom123`.

| E-mail | Rol | Mag beheren? |
| --- | --- | --- |
| john.doe@boonedam.com | Eigenaar | ja, alles |
| jane.doe@boonedam.com | Beheerder | ja, behalve de Eigenaar en andere Beheerders |
| jan.devries@boonedam.com | Bewerker | nee (krijgt 403) |
| sophie.jansen@boonedam.com | Lezer | nee (krijgt 403) |

Er zijn ook twee open uitnodigingen: lisa.bakker@ (Bewerker) en tom.smit@ (Lezer).

Wil je opnieuw beginnen met de voorbeeldgegevens? Leeg dan de tabellen `portal_user`, `portal_user_role` en `invitation`. Of verwijder de database en laat hem opnieuw aanmaken.

## 4. Endpoints voor de Instellingen-pagina

In de front-end gebruik je `/api/auth/...`. De proxy in `vite.config.js` haalt `/api` weg.

| Methode | URL | Stuur mee | Antwoord |
| --- | --- | --- | --- |
| GET | `/auth/users` | | lijst gebruikers (met `isActive`) |
| GET | `/auth/roles` | | de vier rollen |
| GET | `/auth/invitations` | | open uitnodigingen |
| POST | `/auth/invitations` | `{ email, accessRoleId }` | 201 met uitnodiging |
| DELETE | `/auth/invitations/{id}` | | 204 |
| PATCH | `/auth/users/{id}/role` | `{ accessRoleId }` | 200 met gebruiker |
| PATCH | `/auth/users/{id}/status` | `{ isActive: true/false }` | 200 met gebruiker |
| DELETE | `/auth/users/{id}` | | 204 |

`accessRoleId` is een rolcode: `owner`, `admin`, `editor` of `viewer`.

Bij een fout krijg je `{ "error": "leesbare melding" }`. Toon die melding gewoon in de pagina. Wat de codes betekenen:

| Code | Betekenis |
| --- | --- |
| 400 | verkeerde invoer, zoals een ongeldig e-mailadres of een onbekende rol |
| 401 | niet ingelogd |
| 403 | dit mag jij niet |
| 404 | bestaat niet |
| 409 | bestaat al (dubbele uitnodiging, of het account bestaat al) |

## 5. Regels (controleert de backend zelf)

- Alleen Eigenaar en Beheerder (recht `settings`) mogen beheren.
- Je kunt je eigen rol niet wijzigen, en jezelf niet deactiveren of verwijderen.
- Je kunt alleen iemand met een lagere rol dan jij wijzigen.
- Je kunt alleen een rol lager dan die van jou toekennen of uitnodigen.
- Een gedeactiveerde gebruiker kan niet meer inloggen. Dit kun je terugdraaien.
- Verwijderen is definitief. Vraag eerst om bevestiging in de pagina.
- Een uitnodiging verloopt na 30 dagen.

**Tip voor de pagina:** de backend weigert het toch al, maar het is netter om knoppen te verbergen of uit te zetten die iemand niet mag gebruiken. Gebruik daarvoor `currentUser.role.rank` en `user.role.rank`, en vergelijk ook `currentUser.id` met `user.id`.

## 6. Front-end: welke bestanden zijn van wie

| Bestand | Van wie |
| --- | --- |
| `src/services/authService.js`, `App.jsx`, `Login.jsx`, `Register.jsx` | Leo |
| `src/services/userManagementService.js`, `src/pages/Settings.jsx` en de bijbehorende componenten | collega |

Zet `voor-frontend/userManagementService.js` in `src/services/`. Leo zorgt dat `App.jsx` de ingelogde gebruiker als `currentUser` aan `Settings` meegeeft.
