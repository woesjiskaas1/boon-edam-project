// Alle verzoeken voor het beheren van portaalgebruikers (Instellingen-pagina).
// Staat los van authService.js (inloggen/uitloggen), zodat we niet in
// hetzelfde bestand werken en geen merge-conflicten krijgen.
//
// "/api/auth" gaat via de proxy in vite.config.js naar de backend op poort 3333.
// De browser stuurt het sessie-cookie vanzelf mee, dus de backend weet wie
// er is ingelogd.
const API_URL = "/api/auth";

// Verwerkt elk antwoord van de backend op dezelfde manier.
// - 204 (No Content): er komt niets terug, dus geven we null terug.
// - Anders lezen we de JSON.
// - Is het antwoord geen succes (bijv. 400, 403, 409)? Dan gooien we een fout
//   met de melding van de backend, zodat de pagina die kan tonen.
async function handleResponse(response) {
  if (response.status === 204) {
    return null;
  }

  const data = await response.json();

  if (!response.ok) {
    throw new Error(data.error || "Er ging iets mis.");
  }

  return data;
}

// Maakt de instellingen voor een verzoek met JSON-gegevens.
function jsonRequest(method, body) {
  return {
    method: method,
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  };
}

// Alle portaalgebruikers, ook gedeactiveerde (veld isActive).
export async function getPortalUsers() {
  const response = await fetch(`${API_URL}/users`);
  return handleResponse(response);
}

// De vier rollen: [{ code, name, description, rank, permissions }]
export async function getRoles() {
  const response = await fetch(`${API_URL}/roles`);
  return handleResponse(response);
}

// Openstaande uitnodigingen.
export async function getInvitations() {
  const response = await fetch(`${API_URL}/invitations`);
  return handleResponse(response);
}

// Iemand uitnodigen. accessRoleId is een rolcode, bijv. "editor".
export async function inviteUser(email, accessRoleId) {
  const response = await fetch(
    `${API_URL}/invitations`,
    jsonRequest("POST", { email, accessRoleId })
  );
  return handleResponse(response);
}

// Uitnodiging intrekken.
export async function revokeInvitation(invitationId) {
  const response = await fetch(`${API_URL}/invitations/${invitationId}`, {
    method: "DELETE",
  });
  return handleResponse(response);
}

// Rol van een gebruiker wijzigen. Geeft de bijgewerkte gebruiker terug.
export async function changeUserRole(userId, accessRoleId) {
  const response = await fetch(
    `${API_URL}/users/${userId}/role`,
    jsonRequest("PATCH", { accessRoleId })
  );
  return handleResponse(response);
}

// Gebruiker activeren (true) of deactiveren (false).
// Geeft de bijgewerkte gebruiker terug.
export async function setUserActive(userId, isActive) {
  const response = await fetch(
    `${API_URL}/users/${userId}/status`,
    jsonRequest("PATCH", { isActive })
  );
  return handleResponse(response);
}

// Gebruiker definitief verwijderen. Kan niet ongedaan worden gemaakt!
// Vraag in de pagina eerst om bevestiging.
export async function deleteUser(userId) {
  const response = await fetch(`${API_URL}/users/${userId}`, {
    method: "DELETE",
  });
  return handleResponse(response);
}
